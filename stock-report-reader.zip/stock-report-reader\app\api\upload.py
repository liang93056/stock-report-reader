"""上传与解析接口。"""
import os
import shutil
import uuid
from fastapi import APIRouter, UploadFile, File, HTTPException, BackgroundTasks
from app.config import settings
from app.api import task_store
from app.services import pdf_parser, extractor, comparator, risk_extractor
from app.services.rag import ReportIndex
from app.models.schemas import ReportResult, RiskPoint

router = APIRouter(prefix="/api", tags=["upload"])


def _process(task_id: str, current_path: str, previous_path: str | None):
    try:
        parsed = pdf_parser.parse_pdf(current_path)
        metrics = extractor.extract_all(parsed.full_text)
        for m in metrics.values():
            comparator.compute_yoy(m)

        # 风险点
        risk_text = parsed.sections.get("risk", "")
        risks = risk_extractor.extract_risks(risk_text) if risk_text else []

        result = ReportResult(
            revenue=metrics["revenue"],
            net_profit=metrics["net_profit"],
            cashflow=metrics["cashflow"],
            risks=risks,
        )
        index = ReportIndex([c["text"] for c in parsed.chunks])
        task_store.set_result(task_id, result, index)
    except Exception as e:
        task_store.set_error(task_id, "文件解析失败，请检查 PDF 是否损坏或受密码保护")
        print(f"[task {task_id}] error: {e}")
    finally:
        for p in (current_path, previous_path):
            if p and os.path.exists(p):
                try:
                    os.remove(p)
                except OSError:
                    pass


@router.post("/upload")
async def upload(
    background: BackgroundTasks,
    current: UploadFile = File(...),
    previous: UploadFile | None = File(None),
):
    # 校验 MIME
    if current.content_type not in settings.ALLOWED_MIME:
        raise HTTPException(400, "仅支持上传PDF格式文件")
    # 大小校验
    contents = await current.read()
    if len(contents) > settings.MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(400, f"文件超过 {settings.MAX_UPLOAD_MB}MB 限制")

    # 落盘 UUID 重命名
    cur_path = os.path.join(settings.UPLOAD_DIR, f"{uuid.uuid4().hex}.pdf")
    with open(cur_path, "wb") as f:
        f.write(contents)

    prev_path = None
    if previous is not None:
        prev_contents = await previous.read()
        prev_path = os.path.join(settings.UPLOAD_DIR, f"{uuid.uuid4().hex}.pdf")
        with open(prev_path, "wb") as f:
            f.write(prev_contents)

    tid = task_store.create_task()
    background.add_task(_process, tid, cur_path, prev_path)
    return {"task_id": tid}
