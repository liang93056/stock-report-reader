# 部署说明

## 一、本地开发

### 环境要求
- Python 3.10+
- 可访问的 OpenAI 兼容 LLM 接口（或任意兼容服务，如 vLLM、DeepSeek、智谱等）

### 步骤

```bash
# 1. 克隆仓库
git clone <your-repo-url> stock-report-reader
cd stock-report-reader

# 2. 创建虚拟环境（推荐）
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
# source .venv/bin/activate

# 3. 安装依赖
pip install -r requirements.txt

# 4. 配置环境变量
cp .env.example .env
# 编辑 .env：
#   LLM_API_KEY=sk-...
#   LLM_BASE_URL=https://api.openai.com/v1
#   LLM_MODEL=gpt-4o-mini

# 5. 启动开发服务器
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

打开 http://localhost:8000 即可。

---

## 二、生产部署

### 方案 A：直接用 Uvicorn（单实例，够用）

```bash
pip install -r requirements.txt
uvicorn app.main:app --host 127.0.0.1 --port 8000 --workers 2
```

前面挂 Nginx 做 HTTPS 终止：

```nginx
server {
    listen 443 ssl;
    server_name your-domain.com;
    ssl_certificate     /path/to/cert.pem;
    ssl_certificate_key /path/to/key.pem;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_read_timeout 120s;
    }
}
```

### 方案 B：Docker

```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
EXPOSE 8000
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

```bash
docker build -t stock-report-reader .
docker run -d -p 8000:8000 --env-file .env stock-report-reader
```

---

## 三、环境变量

| 变量 | 必填 | 默认值 | 说明 |
|---|---|---|---|
| `LLM_API_KEY` | 是 | 无 | OpenAI 兼容接口密钥 |
| `LLM_BASE_URL` | 否 | `https://api.openai.com/v1` | 兼容接口地址 |
| `LLM_MODEL` | 否 | `gpt-4o-mini` | 对话模型名 |
| `EMBEDDING_MODEL` | 否 | `text-embedding-3-small` | Embedding 模型名 |
| `MAX_UPLOAD_MB` | 否 | `50` | 单文件大小上限 |
| `TASK_TTL_HOURS` | 否 | `2` | 任务结果内存保留时长 |

---

## 四、运行测试

```bash
pip install pytest
pytest tests/ -v
```

预期：5 个测试文件全部通过，覆盖同比计算、指标抽取、RAG 检索、API 基础路径。

---

## 五、注意事项

1. 当前任务存储为内存字典，**仅适合单实例部署**。多实例或重启后任务丢失，生产建议换 Redis。
2. 上传的 PDF 处理完即删除，但 `uploads/` 目录需确保磁盘权限正确。
3. LLM 接口需要外网访问；内网部署请确认 `LLM_BASE_URL` 可达。
4. 首次启动会自动创建 `uploads/` 目录。
