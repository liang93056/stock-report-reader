"""AI 问答接口。"""
from fastapi import APIRouter, HTTPException
from app.api import task_store
from app.models.schemas import ChatRequest, ChatResponse

router = APIRouter(prefix="/api/chat", tags=["chat"])


@router.post("", response_model=ChatResponse)
def chat(req: ChatRequest):
    rec = task_store.get_task(req.task_id)
    if rec is None:
        raise HTTPException(404, "任务不存在")
    if rec["status"].status != "done":
        raise HTTPException(400, "请等待财报解析完成后再进行提问")
    if not req.question.strip():
        raise HTTPException(400, "问题不能为空")
    if len(req.question) > 500:
        raise HTTPException(400, "问题不超过 500 字")

    answer, sources = rec["index"].ask(req.question, req.history)
    return ChatResponse(answer=answer, sources=sources)
