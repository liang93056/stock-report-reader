"""同比对比计算测试。"""
from app.models.schemas import MetricResult
from app.services.comparator import compute_yoy


def test_normal_yoy_growth():
    m = MetricResult(name="营业收入", current=120.0, previous=100.0)
    compute_yoy(m)
    assert m.yoy_change is not None
    assert abs(m.yoy_change - 0.20) < 1e-6
    assert "增长" in m.comment


def test_normal_yoy_decline():
    m = MetricResult(name="净利润", current=80.0, previous=100.0)
    compute_yoy(m)
    assert m.yoy_change < 0
    assert "下降" in m.comment


def test_no_previous_period():
    m = MetricResult(name="营业收入", current=120.0, previous=None)
    compute_yoy(m)
    assert m.yoy_change is None
    assert "未上传" in m.comment


def test_near_zero_previous():
    m = MetricResult(name="净利润", current=100.0, previous=0.0000001)
    compute_yoy(m)
    assert m.yoy_change is None
    assert "基数" in m.comment


def test_no_current_value():
    m = MetricResult(name="现金流", current=None, previous=None)
    compute_yoy(m)
    assert m.yoy_change is None
