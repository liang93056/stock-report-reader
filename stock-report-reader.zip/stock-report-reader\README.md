# 上市公司财报速读小工具

上传当期与去年同期上市公司财报 PDF，约 30 秒输出收入、利润、现金流、风险点四维度核心结论及同比对比，并提供基于 RAG 的财报 AI 问答。

在线体验：https://app-fdpimzib0c1t.miaoda.online

## 功能

- PDF 上传（本期必选、去年同期可选），前端格式与大小校验
- 自动提取营业收入、净利润、经营活动现金流，计算同比变动
- 基于「管理层讨论与分析」「风险提示」章节归纳不超过 5 条风险点
- AI 问答浮窗：答案严格基于已上传财报原文，未披露则如实说明
- 会话级临时存储：任务完成后自动清理，不做历史归档

## 技术栈

| 层 | 选型 |
|---|---|
| 后端 | Python 3.10+ / FastAPI / Uvicorn |
| PDF 解析 | PyMuPDF（文本+表格）、pdfplumber（兜底） |
| LLM | OpenAI 兼容接口（任意兼容服务） |
| 向量检索 | numpy 余弦相似度（轻量，无需 FAISS） |
| 前端 | 原生 HTML / CSS / JS（单页，无构建步骤） |
| 任务 | FastAPI BackgroundTasks + 内存字典（单实例） |

## 快速开始

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 配置环境变量
cp .env.example .env
# 编辑 .env，填入 LLM_API_KEY 与 LLM_BASE_URL

# 3. 启动
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

浏览器打开 http://localhost:8000 即可使用。

## 运行测试

```bash
pip install pytest
pytest tests/ -v
```

## 目录结构

```
stock-report-reader/
├── app/
│   ├── main.py              # FastAPI 入口
│   ├── config.py            # 环境配置
│   ├── api/                 # 路由：上传 / 任务状态 / 问答
│   ├── services/            # 核心算法：PDF解析 / 指标抽取 / 同比 / 风险 / RAG
│   ├── models/              # Pydantic 数据模型
│   └── static/index.html    # 前端单页
├── tests/                   # pytest 用例
├── deploy/DEPLOYMENT.md     # 部署说明
└── requirements.txt
```

## 安全说明

- 上传文件落盘重命名为 UUID，不使用用户原文件名
- 仅接受 PDF MIME，单文件 ≤ 50MB
- 临时文件与向量索引 TTL 2 小时自动清理
- LLM 返回在前端做 HTML 转义，接口加限流
- 错误信息统一文案，不暴露内部堆栈

## License

MIT
