"""应用配置：从环境变量读取，带合理默认值。"""
import os
from dotenv import load_dotenv

load_dotenv()


class Settings:
    LLM_API_KEY: str = os.getenv("LLM_API_KEY", "")
    LLM_BASE_URL: str = os.getenv("LLM_BASE_URL", "https://api.openai.com/v1")
    LLM_MODEL: str = os.getenv("LLM_MODEL", "gpt-4o-mini")
    EMBEDDING_MODEL: str = os.getenv("EMBEDDING_MODEL", "text-embedding-3-small")

    MAX_UPLOAD_MB: int = int(os.getenv("MAX_UPLOAD_MB", "50"))
    TASK_TTL_HOURS: int = int(os.getenv("TASK_TTL_HOURS", "2"))

    UPLOAD_DIR: str = os.path.join(os.getcwd(), "uploads")
    ALLOWED_MIME = {"application/pdf"}


settings = Settings()
os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
