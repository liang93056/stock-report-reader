"""RAG 索引测试（使用 mock embedding）。"""
from app.services.rag import ReportIndex


def test_retrieve_returns_relevant_chunk(monkeypatch):
    chunks = [
        "公司研发费用投入占营业收入比例为 8.5%，同比提升 1.2 个百分点。",
        "公司海外业务收入占比约 30%，主要来自东南亚市场。",
        "公司经营活动现金流净额为 12 亿元，同比改善。",
    ]
    # 词袋 mock：统计每 2-gram 出现频率作为向量
    vocab = {}
    def to_vec(text):
        vec = [0.0] * 64
        for i in range(len(text) - 1):
            key = text[i:i+2]
            vid = vocab.setdefault(key, len(vocab) % 64)
            vec[vid] += 1.0
        return vec
    def fake_embed(texts):
        return [to_vec(t) for t in texts]
    monkeypatch.setattr("app.services.rag.embed", fake_embed)

    idx = ReportIndex(chunks)
    hits = idx.retrieve("研发费用占比", top_k=1)
    assert len(hits) == 1
    assert "研发费用" in hits[0][1]


def test_empty_index_ask():
    idx = ReportIndex([])
    answer, sources = idx.ask("任何问题")
    assert "未披露" in answer
    assert sources == []
