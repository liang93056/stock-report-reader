"""内存任务存储（单实例演示用，生产可换 Redis）。"""
import time
import uuid
from threading import Lock
from app.models.schemas import TaskStatus, ReportResult
from app.services.rag import ReportIndex


_store: dict[str, dict] = {}
_lock = Lock()


def create_task() -> str:
    tid = uuid.uuid4().hex[:12]
    with _lock:
        _store[tid] = {
            "status": TaskStatus(task_id=tid),
            "index": None,
            "created_at": time.time(),
        }
    return tid


def get_task(tid: str) -> dict | None:
    return _store.get(tid)


def set_result(tid: str, result: ReportResult, index: ReportIndex):
    with _lock:
        if tid in _store:
            _store[tid]["status"].status = "done"
            _store[tid]["status"].result = result
            _store[tid]["index"] = index


def set_error(tid: str, msg: str):
    with _lock:
        if tid in _store:
            _store[tid]["status"].status = "failed"
            _store[tid]["status"].message = msg
