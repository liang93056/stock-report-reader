"""RAG 问答：向量检索 + LLM 生成。"""
import numpy as np
from app.services.llm_client import embed, chat_completion


SYSTEM_PROMPT = """你是财报问答助手。只能根据下面提供的财报原文片段回答问题。
如果原文片段中没有相关信息，必须明确回答「财报中未披露相关信息」，不要编造数字或事实。
回答要简洁，关键数字后用括号标注来源片段编号。"""


def _cosine(a: list[float], b: list[float]) -> float:
    va, vb = np.array(a), np.array(b)
    return float(np.dot(va, vb) / (np.linalg.norm(va) * np.linalg.norm(vb) + 1e-8))


class ReportIndex:
    """单会话财报向量索引。"""

    def __init__(self, chunks: list[str]):
        self.chunks = chunks
        self.vectors = embed(chunks) if chunks else []

    def retrieve(self, query: str, top_k: int = 3) -> list[tuple[int, str]]:
        if not self.vectors:
            return []
        qv = embed([query])[0]
        scored = [(i, _cosine(qv, v)) for i, v in enumerate(self.vectors)]
        scored.sort(key=lambda x: x[1], reverse=True)
        return [(i, self.chunks[i]) for i, _ in scored[:top_k]]

    def ask(self, question: str, history: list[dict] | None = None) -> tuple[str, list[str]]:
        hits = self.retrieve(question, top_k=3)
        if not hits:
            return "财报中未披露相关信息。", []
        context = "\n\n".join(f"[片段{i+1}] {txt}" for i, (_, txt) in enumerate(hits))
        user_msg = f"问题：{question}\n\n财报原文片段：\n{context}"
        answer = chat_completion(user_msg, system=SYSTEM_PROMPT, temperature=0.1)
        return answer, [f"片段{i+1}" for i in range(len(hits))]
