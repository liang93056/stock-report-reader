"""PDF 解析：文本抽取、表格识别、章节定位、分块。"""
import re
from dataclasses import dataclass

import fitz  # PyMuPDF


@dataclass
class ParsedReport:
    full_text: str
    sections: dict[str, str]   # 章节名 -> 正文
    tables: list[list[list[str]]]
    chunks: list[dict]         # {"text":..., "section":...}


# 章节标题关键词
SECTION_PATTERNS = {
    "md&a": r"管理层讨论与分析|经营情况讨论与分析|管理层报告",
    "risk": r"风险因素|面临的风险|主要风险|风险提示|可能面对的风险",
    "income_statement": r"合并利润表|利润表",
    "cashflow_statement": r"合并现金流量表|现金流量表",
}


def extract_text(pdf_path: str) -> str:
    """按页面、按 block 阅读顺序抽取全文。"""
    doc = fitz.open(pdf_path)
    parts = []
    for page in doc:
        # sort=True 按阅读顺序返回
        parts.append(page.get_text("text", sort=True))
    doc.close()
    return "\n".join(parts)


def split_sections(text: str) -> dict[str, str]:
    """粗定位 MD&A、风险、三大报表章节。"""
    sections = {}
    lines = text.split("\n")
    for key, pattern in SECTION_PATTERNS.items():
        for i, line in enumerate(lines):
            if re.search(pattern, line):
                # 取后续 200 行作为该章节内容
                sections[key] = "\n".join(lines[i + 1:i + 200])
                break
    return sections


def extract_tables(pdf_path: str) -> list[list[list[str]]]:
    """尝试抽取表格，失败返回空列表。"""
    tables = []
    try:
        import pdfplumber
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages[:30]:  # 只扫前 30 页主要报表
                for t in page.extract_tables():
                    tables.append(t)
    except Exception:
        pass
    return tables


def chunk_text(text: str, size: int = 400, overlap: int = 50) -> list[str]:
    """按字符长度分块，带 overlap。"""
    chunks = []
    start = 0
    while start < len(text):
        end = start + size
        chunks.append(text[start:end])
        start = end - overlap
    return chunks


def parse_pdf(pdf_path: str) -> ParsedReport:
    full_text = extract_text(pdf_path)
    sections = split_sections(full_text)
    tables = extract_tables(pdf_path)
    chunks = [{"text": c, "section": ""} for c in chunk_text(full_text)]
    return ParsedReport(full_text=full_text, sections=sections,
                        tables=tables, chunks=chunks)
