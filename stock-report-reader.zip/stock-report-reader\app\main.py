"""FastAPI 入口。"""
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from app.api import upload, task, chat

app = FastAPI(title="财报速读小工具")

app.include_router(upload.router)
app.include_router(task.router)
app.include_router(chat.router)


@app.get("/")
def index():
    return FileResponse("app/static/index.html")


app.mount("/static", StaticFiles(directory="app/static"), name="static")
