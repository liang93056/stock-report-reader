"""指标抽取测试（不依赖真实 PDF，直接喂文本）。"""
from app.services.extractor import extract_metric, REVENUE_KEYS, PROFIT_KEYS


def test_extract_revenue_basic():
    text = """
    合并利润表
    项目            本期数        上年同期
    营业收入        1,234,500.00  1,000,000.00
    营业成本        800,000.00    700,000.00
    """
    m = extract_metric(text, REVENUE_KEYS, "营业收入")
    assert m.current is not None
    # 文本里单位未明确标注万元/亿元，默认按元处理 -> /1e8
    # 1,234,500 元 = 0.012 亿元
    assert m.current > 0


def test_extract_profit_fallback():
    text = "归属于母公司股东的净利润 56,789.00 万元"
    m = extract_metric(text, PROFIT_KEYS, "净利润")
    assert m.current is not None
    # 56789 万元 = 5.6789 亿元
    assert abs(m.current - 5.6789) < 0.01


def test_extract_missing_metric():
    text = "这段文字里完全没有收入相关行项目"
    m = extract_metric(text, REVENUE_KEYS, "营业收入")
    assert m.current is None


def test_to_yi_conversion():
    from app.services.extractor import _to_yi
    assert abs(_to_yi(50000.0, "万元") - 5.0) < 1e-6
    assert abs(_to_yi(5e8, "元") - 5.0) < 1e-6
    assert abs(_to_yi(3.5, "亿元") - 3.5) < 1e-6
