"""风险点抽取：定位风险章节，调用 LLM 归纳要点。"""
from app.models.schemas import RiskPoint
from app.services.llm_client import chat_completion


RISK_PROMPT = """你是财报分析助手。请从下面财报的风险章节文本中，提炼不超过 5 条关键风险点，
按业务风险、财务风险、审计提示三类归类。每条不超过 60 字。
只输出 JSON 数组，格式：[{{"text":"...","category":"业务风险"}}]。
文本中没有的风险不要编造。

风险章节原文：
{text}
"""


def extract_risks(risk_section: str) -> list[RiskPoint]:
    if not risk_section or len(risk_section) < 50:
        return []
    prompt = RISK_PROMPT.format(text=risk_section[:4000])
    raw = chat_completion(prompt, temperature=0.1)
    # 简单解析 JSON 数组
    import json
    try:
        data = json.loads(raw)
        return [RiskPoint(**item) for item in data[:5]]
    except Exception:
        return [RiskPoint(text="风险章节解析失败，请人工查看原文", category="其他")]
