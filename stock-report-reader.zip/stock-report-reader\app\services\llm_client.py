"""LLM 与 Embedding 客户端封装。"""
from app.config import settings


def chat_completion(prompt: str, system: str = "", temperature: float = 0.2) -> str:
    """调用 OpenAI 兼容 chat 接口。未配置 key 时返回占位文本，便于本地开发。"""
    if not settings.LLM_API_KEY:
        return "[未配置 LLM_API_KEY，返回占位结果]"
    from openai import OpenAI
    client = OpenAI(api_key=settings.LLM_API_KEY, base_url=settings.LLM_BASE_URL)
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})
    resp = client.chat.completions.create(
        model=settings.LLM_MODEL, messages=messages, temperature=temperature
    )
    return resp.choices[0].message.content or ""


def embed(texts: list[str]) -> list[list[float]]:
    """批量 embedding。未配置时返回随机向量（仅供测试）。"""
    if not settings.LLM_API_KEY:
        import random
        return [[random.random() for _ in range(16)] for _ in texts]
    from openai import OpenAI
    client = OpenAI(api_key=settings.LLM_API_KEY, base_url=settings.LLM_BASE_URL)
    resp = client.embeddings.create(model=settings.EMBEDDING_MODEL, input=texts)
    return [d.embedding for d in resp.data]
