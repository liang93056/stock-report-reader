"""财务指标抽取：规则正则为主，LLM 校验为辅。"""
import re
from app.models.schemas import MetricResult


# 行项目关键词
REVENUE_KEYS = ["营业收入", "营业总收入"]
PROFIT_KEYS = ["归属于母公司股东的净利润", "净利润", "扣非净利润"]
CASHFLOW_KEYS = ["经营活动产生的现金流量净额", "经营活动现金流量净额"]


def _to_yi(value: float, unit_text: str) -> float:
    """把不同单位统一换算为亿元。"""
    if "亿元" in unit_text:
        return value
    if "万元" in unit_text:
        return value / 10000.0
    # 仅"元"，不含万/亿
    return value / 1e8


def _find_number_after(label: str, text: str) -> float | None:
    """在 label 出现的位置附近找第一个数字（支持千分位、负数）。"""
    idx = text.find(label)
    if idx < 0:
        return None
    window = text[idx:idx + 200]
    m = re.search(r"-?[\d,]+(?:\.\d+)?", window)
    if not m:
        return None
    num = float(m.group().replace(",", ""))
    # 判断单位
    unit = "元"
    if "万元" in window[:100]:
        unit = "万元"
    elif "亿元" in window[:100]:
        unit = "亿元"
    return _to_yi(num, unit)


def extract_metric(text: str, keys: list[str], name: str) -> MetricResult:
    """抽取单指标：同时尝试找本期和上期列。"""
    current = None
    previous = None
    for k in keys:
        current = _find_number_after(k, text)
        if current is not None:
            break
    # 尝试找上年同期（简单策略：找"上年"附近的同名 label）
    prev_match = re.search(r"上年(?:度|同期|年末)?", text)
    if prev_match:
        for k in keys:
            previous = _find_number_after(k, text[prev_match.start():prev_match.start() + 500])
            if previous is not None:
                break
    return MetricResult(name=name, current=current, previous=previous)


def extract_all(full_text: str) -> dict:
    revenue = extract_metric(full_text, REVENUE_KEYS, "营业收入")
    profit = extract_metric(full_text, PROFIT_KEYS, "净利润")
    cashflow = extract_metric(full_text, CASHFLOW_KEYS, "经营活动现金流")
    return {"revenue": revenue, "net_profit": profit, "cashflow": cashflow}
