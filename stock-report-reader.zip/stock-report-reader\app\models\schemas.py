"""Pydantic 数据模型。"""
from typing import Optional
from pydantic import BaseModel


class MetricResult(BaseModel):
    """单指标抽取结果。"""
    name: str
    current: Optional[float] = None       # 本期值（亿元）
    previous: Optional[float] = None      # 同期值（亿元）
    yoy_change: Optional[float] = None    # 同比变动率，小数，如 0.123 表示 +12.3%
    comment: str = ""
    unit: str = "亿元"


class RiskPoint(BaseModel):
    text: str
    category: str = "其他"  # 业务 / 财务 / 审计


class ReportResult(BaseModel):
    revenue: MetricResult
    net_profit: MetricResult
    cashflow: MetricResult
    risks: list[RiskPoint] = []


class TaskStatus(BaseModel):
    task_id: str
    status: str = "pending"   # pending / processing / done / failed
    message: str = ""
    result: Optional[ReportResult] = None


class ChatRequest(BaseModel):
    task_id: str
    question: str
    history: list[dict] = []


class ChatResponse(BaseModel):
    answer: str
    sources: list[str] = []
