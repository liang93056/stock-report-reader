"""同比对比计算。"""
from app.models.schemas import MetricResult


def compute_yoy(metric: MetricResult) -> MetricResult:
    """计算同比变动率。同期接近 0 时不返回百分比。"""
    if metric.current is None:
        return metric
    if metric.previous is None:
        metric.yoy_change = None
        if not metric.comment:
            metric.comment = "未上传对比财报"
        return metric

    prev = metric.previous
    if abs(prev) < 1e-6:
        metric.yoy_change = None
        metric.comment = "同期基数接近零，仅展示变动额"
        return metric

    metric.yoy_change = (metric.current - prev) / abs(prev)
    pct = metric.yoy_change * 100
    direction = "增长" if pct >= 0 else "下降"
    metric.comment = f"同比{direction} {abs(pct):.1f}%"
    return metric
