"""任务状态查询。"""
from fastapi import APIRouter, HTTPException
from app.api import task_store

router = APIRouter(prefix="/api/task", tags=["task"])


@router.get("/{task_id}")
def status(task_id: str):
    rec = task_store.get_task(task_id)
    if rec is None:
        raise HTTPException(404, "任务不存在")
    return rec["status"]
