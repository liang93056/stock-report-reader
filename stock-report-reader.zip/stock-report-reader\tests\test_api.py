"""API 集成测试：用 TestClient。"""
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)


def test_index_page():
    r = client.get("/")
    assert r.status_code == 200
    assert "财报速读" in r.text


def test_upload_no_file():
    # 不传 current 文件应返回 400
    r = client.post("/api/upload")
    assert r.status_code in (400, 422)


def test_chat_before_done():
    # 用一个不存在的 task_id 问答应 404
    r = client.post("/api/chat", json={"task_id": "notexist", "question": "hi"})
    assert r.status_code == 404


def test_task_not_found():
    r = client.get("/api/task/nonexistent")
    assert r.status_code == 404
